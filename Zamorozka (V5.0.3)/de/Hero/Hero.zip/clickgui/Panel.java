package de.Hero.clickgui;

import java.awt.Color;

import java.sql.Date;
import java.util.ArrayList;
import java.util.TimerTask;

import javax.management.timer.Timer;

import net.minecraft.client.gui.Gui;
import zamorozka.main.Zamorozka;
import de.Hero.clickgui.elements.ModuleButton;
import de.Hero.clickgui.util.ColorUtil;
import de.Hero.clickgui.util.FontUtil;

/**
 *  Made by HeroCode
 *  it's free to use
 *  but you have to credit me
 *
 *  @author HeroCode
 */
public class Panel {
	public String title;
	public double x;
	public double y;
	private double x2;
	private double y2;
	public double width;
	public double height;
	public boolean dragging;
	public boolean extended;
	public boolean visible;
	public ArrayList<ModuleButton> Elements = new ArrayList<>();
	public ClickGUI clickgui;
	int delay;
	/*
	 * Konstrukor
	 */
	public Panel(String ititle, double ix, double iy, double iwidth, double iheight, boolean iextended, ClickGUI parent) {
		this.title = ititle;
		this.x = ix;
		this.y = iy;
		this.width = iwidth;
		this.height = iheight;
		this.extended = iextended;
		this.dragging = false;
		this.visible = true;
		this.clickgui = parent;
		setup();
	}

	/*
	 * Wird in ClickGUI berschrieben, sodass auch ModuleButtons hinzugefgt werden knnen :3
	 */
	public void setup() {}

	/*
	 * Rendern des Elements.
	 */
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		if (!this.visible)
			return;

		if (this.dragging) {
			x = x2 + mouseX;
			y = y2 + mouseY;
		}
		
		Color temp = ColorUtil.getClickGUIColor().darker();
		int outlineColor = new Color(temp.getRed(), temp.getGreen(), temp.getBlue(), 170).getRGB();
		Gui.drawRect(x, y, x + width, y + height,  0x5050506);
		if(Zamorozka.settingsManager.getSettingByName("Design").getValString().equalsIgnoreCase("New")){
			if(Zamorozka.settingsManager.getSettingByName("Type").getValString().equalsIgnoreCase("Defaulted")){
				Gui.drawRect(x-4, y, x + width+4, y + height, 0xFF5050FD);
				Gui.drawRect(x, y+17, x + width, y + height, 0xFF1CF196);
			}else{
				Gui.drawRect(x, y, x + width, y + height, setRainbow(10000000L * y2, 1.0F).getRGB());
			}
		}
		if(Zamorozka.settingsManager.getSettingByName("Design").getValString().equalsIgnoreCase("New")){
			if(Zamorozka.settingsManager.getSettingByName("Type").getValString().equalsIgnoreCase("Defaulted")){
				
				Gui.drawRect(x - 4, y+17, x, y + height, 0xFF2A9AC6);
				
				FontUtil.drawStringWithShadow(title, x + 2, y + height / 2 - FontUtil.getFontHeight()/2, 0xffefefef);
				
			}else{
				Gui.drawRect(x - 2, y, x, y + height, setRainbow(10000000L * y2, 1.0F).getRGB());
				FontUtil.drawStringWithShadow(title, x + 2, y + height / 2 - FontUtil.getFontHeight()/2, 0xffefefef);
				
			}

		}//else if(Zamorozka.settingsManager.getSettingByName("Design").getValString().equalsIgnoreCase("JellyLike")){
			//Gui.drawRect(x + 4,			y + 2, x + 4.3, 		y + height - 2, 0xffaaaaaa);
			//Gui.drawRect(x - 4 + width, y + 2, x - 4.3 + width, y + height - 2, 0xffaaaaaa);
			//FontUtil.drawTotalCenteredStringWithShadow(title, x + width / 2, y + height / 2, 0xffefefef);
		//}
		
		if (this.extended && !Elements.isEmpty()) {
			
			double startY = y + height;
			int epanelcolor = Zamorozka.settingsManager.getSettingByName("Design").getValString().equalsIgnoreCase("New") ? 0xff232323 : Zamorozka.settingsManager.getSettingByName("Design").getValString().equalsIgnoreCase("JellyLike") ? 0xbb151515 : 0;;
			
			for (ModuleButton et : Elements) {
				Gui.drawRect(x + 86, startY-1, x + width, startY + et.height + 1, 0xFF1CF196);
				Gui.drawRect(x, startY, x - width+84, startY + et.height + 1, 0xFF1CF196);
				if(Zamorozka.settingsManager.getSettingByName("Type").getValString().equalsIgnoreCase("Defaulted")){
					Gui.drawRect(x, startY, x + width, startY + et.height + 1, 0x88101010);
				}else{
					Gui.drawRect(x - 2, startY, x + width, startY + et.height + 1, 0x88101010);
				}
				Gui.drawRect(x,startY, x + width, startY + et.height + 1, 0x88101010);
				et.x = x + 2;
				et.y = startY;
				et.width = width - 4;
				et.drawScreen(mouseX, mouseY, partialTicks);
				startY += et.height + 1;
			}
			Gui.drawRect(x, startY + 1, x + width, startY + 1, 0xFF22FFB5);
			Zamorozka.FONT_MANAGER.chat.drawStringWithShadow("<", (float)x+70, (float)y+5, 0xFFFAFA);
		}else{
			Zamorozka.FONT_MANAGER.chat.drawStringWithShadow(">", (float)x+70, (float)y+5, 0xFFFAFA);
		}
		
	}
	public static Color setRainbow(double d, float fade) {

		    float hue = (float)(System.nanoTime() * -5L + d) / 1.0E10F % 1.0F;
		    long color = Long.parseLong(Integer.toHexString(Integer.valueOf(Color.HSBtoRGB(hue, 1.0F, 1.0F)).intValue()), 16);
		    Color c = new Color((int)color);
		    return new Color(c.getRed() / 255.0F * fade, c.getGreen() / 255.0F * fade, c.getBlue() / 255.0F * fade);
	   
	}
	/*
	 * Zum Bewegen und Extenden des Panels
	 * usw.
	 */
	
	public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
		if (!this.visible) {
			return false;
		}
		if (mouseButton == 0 && isHovered(mouseX, mouseY)) {
			x2 = this.x - mouseX;
			y2 = this.y - mouseY;
			dragging = true;
			return true;
		} else if (mouseButton == 1 && isHovered(mouseX, mouseY)) {
			extended = !extended;
			return true;
		} else if (extended) {
			for (ModuleButton et : Elements) {
				if (et.mouseClicked(mouseX, mouseY, mouseButton)) {
					return true;
				}
			}
		}
		return false;
	}

	/*
	 * Damit das Panel auch losgelassen werden kann 
	 */
	public void mouseReleased(int mouseX, int mouseY, int state) {
		if (!this.visible) {
			return;
		}
		if (state == 0) {
			this.dragging = false;
		}
	}

	/*
	 * HoverCheck
	 */
	public boolean isHovered(int mouseX, int mouseY) {
		return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
	}
}
